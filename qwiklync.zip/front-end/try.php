<button name = "button" onclick="<?php trial(); ?>">Click</button>

<?php
function trial(){
	header("Location:try2.php") ;
}

?>